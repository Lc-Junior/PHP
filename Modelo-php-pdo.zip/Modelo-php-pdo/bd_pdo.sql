CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8;
USE `mydb` ;


CREATE TABLE IF NOT EXISTS `mydb`.`usuario` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `email` VARCHAR(100) NOT NULL,
  `senha` VARCHAR(30) NOT NULL,
  `idade` INT NOT NULL,
  `celular` VARCHAR(15) NOT NULL,
  `sexo` VARCHAR(15) NOT NULL,
  `data_nascimento` DATE NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `mydb`.`perfil` (
  `id` INT NOT NULL,
  `altura` VARCHAR(45) NOT NULL,
  `peso` DECIMAL(3,2) NOT NULL,
  `atividade_fisica` VARCHAR(50) NOT NULL,
  `objetivo` VARCHAR(20) NOT NULL,
  `biotipo` VARCHAR(15) NOT NULL,
  `UsuariosPer_id` INT NOT NULL,
  PRIMARY KEY (`id`),
    FOREIGN KEY (`UsuariosPer_id`)
    REFERENCES `mydb`.`usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


CREATE TABLE IF NOT EXISTS `mydb`.`alimentacao` (
  `id` INT NOT NULL,
  `agua` INT NOT NULL,
  `calorias` INT NOT NULL,
  `cafe` VARCHAR(100) NULL,
  `almoco` VARCHAR(100) NULL,
  `lanchetarde` VARCHAR(100) NULL,
  `janta` VARCHAR(100) NULL,
  `lanchenoite` VARCHAR(100) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


CREATE TABLE IF NOT EXISTS `mydb`.`medicamentos` (
  `id` INT NOT NULL,
  `medicamento` VARCHAR(45) NULL,
  `descricao` VARCHAR(100) NULL,
  `UsuariosMed_id` INT NOT NULL,
  PRIMARY KEY (`id`),
    FOREIGN KEY (`UsuariosMed_id`)
    REFERENCES `mydb`.`usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


CREATE TABLE IF NOT EXISTS `mydb`.`alimentacaoUsuario` (
  `Alimentacao_id` INT NOT NULL,
  `Usuarios_id` INT NOT NULL,
  PRIMARY KEY (`Alimentacao_id`, `Usuarios_id`),
    FOREIGN KEY (`Alimentacao_id`)
    REFERENCES `mydb`.`alimentacao` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Alimentacao_has_Usuarios_Usuarios1`
    FOREIGN KEY (`Usuarios_id`)
    REFERENCES `mydb`.`usuario` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

