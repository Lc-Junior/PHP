CREATE SCHEMA IF NOT EXISTS `Bugiganga` DEFAULT CHARACTER SET utf8;
USE `Bugiganga`;

CREATE TABLE IF NOT EXISTS `Bugiganga`.`Locatario`(
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
`nome` VARCHAR (60) NOT NULL,
`devolvido` BOOLEAN NOT NULL
) ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `Bugiganga`.`Item`(
`id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
`nome` VARCHAR (60) NOT NULL,
`data_emprestimo` DATE NOT NULL,
`idlocatario` INT NOT NULL,
FOREIGN KEY(`idlocatario`)
REFERENCES `Bugiganga`.`Locatario`(`id`)
ON UPDATE NO ACTION
ON DELETE NO ACTION
) ENGINE = InnoDB;

select* from locatario;
select * from item;

drop database bugiganga;