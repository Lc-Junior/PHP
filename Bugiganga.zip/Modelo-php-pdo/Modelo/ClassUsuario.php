<?php
class ClassUsuario
{
    private $idUsuario;
    private $nome;
    private $devolvido;
    private $nomeitem;
    private $dataemprestimo;

    function getIdUsuario()
    {
        return $this->idUsuario;
    }

    function getNome()
    {
        return $this->nome;
    }

    function getDevolvido()
    {
        return $this->devolvido;
    }

    function getNomeitem()
    {
        return $this->nomeitem;
    }

    function getDataemprestimo()
    {
        return $this->dataemprestimo;
        }

    function setIdUsuario($idUsuario)
    {
        $this->idUsuario = $idUsuario;
    }

    function setNome($nome)
    {
        $this->nome = $nome;
    }

    function setDevolvido($devolvido)
    {
        $this->devolvido = $devolvido;
    }

    function setNomeitem($nomeitem)
    {
        $this->nomeitem = $nomeitem;
    }

    function setDataemprestimo($dataemprestimo)
    {
        $this->dataemprestimo = $dataemprestimo;
    }
}
