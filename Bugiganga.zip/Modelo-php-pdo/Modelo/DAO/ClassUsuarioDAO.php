<?php
require_once 'Conexao.php';
class ClassUsuarioDAO
{
    public function cadastrar(ClassUsuario $cadastrarUsuario)
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "INSERT INTO Locatario (nome, devolvido) values (?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadastrarUsuario->getNome());
            $stmt->bindValue(2, $cadastrarUsuario->getDevolvido());
            $stmt->execute();
            return TRUE;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function cadastrarItem(ClassUsuario $cadastrarItem)
    {

        try{
            $pdo = Conexao::getInstance();
            return $pdo->lastInsertId();
            $idLocatario = $pdo->lastInsertId();
            $sql = "INSERT INTO Item (nome, data_emprestimo, idLocatario) values (?,?,?)";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $cadastrarItem->getNomeitem());
            $stmt->bindValue(2, $cadastrarItem->getDataemprestimo());
            $stmt->bindValue(3, $idLocatario);
            $stmt->execute();
            return TRUE;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }

    public function buscarUsuario($devolvido)
    {
        try {
            $usuario = new ClassUsuario();
            $pdo = Conexao::getInstance();
            $sql = "SELECT idUsuario, nome, devolvido FROM Locatario WHERE devolvido = 'false' LIMIT 1";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(false, $devolvido);

            $stmt->execute();
            $usuarioAssoc = $stmt->fetch(PDO::FETCH_ASSOC);

            $usuario->setIdUsuario($usuarioAssoc['idUsuario']);
            $usuario->setNome($usuarioAssoc['nome']);
            $usuario->setDevolvido($usuarioAssoc['boolean']);

            return $usuario;
        } catch (PDOException $ex) {
            return $ex->getMessage();
        }
    }
    public function listarUsuarios()
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "SELECT * FROM item";
            $stmt = $pdo->prepare($sql);
            $stmt->execute();
            $itens = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $itens;
        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }
    }


    public function alterarUsuario(ClassUsuario $alterarUsuario)
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "UPDATE Locatario SET nome=?, devolvido=? WHERE idUsuario=? ";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(1, $alterarUsuario->getNome());
            $stmt->bindValue(2, $alterarUsuario->getDevolvido());
            $stmt->bindValue(3, $alterarUsuario->getIdUsuario());
            $stmt->execute();
            return $stmt->rowCount();
        } catch (PDOException $ex) {
            echo $ex->getMessage();
        }
    }

    public function excluirUsuarios($idUsuario)
    {
        try {
            $pdo = Conexao::getInstance();
            $sql = "DELETE FROM Locatario WHERE idUsuario =:idUsuario";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':idUsuario', $idUsuario);
            $stmt->execute();
            return TRUE;
        } catch (PDOException $exc) {
            // echo $ex->getMessage();
        }
    }
}