create database crud_php_pdo;

use crud_php_pdo;

create table usuario(idUsuario int primary key auto_increment, nome varchar(45), email varchar(60));

